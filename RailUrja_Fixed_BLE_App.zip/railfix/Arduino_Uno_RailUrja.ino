#include <SoftwareSerial.h>
#include <DHT.h>

// Uno D10 = TX to ESP32 GPIO16 through voltage divider.
// Uno D11 = RX from ESP32 GPIO17 (not needed for telemetry, but wired for UART).
SoftwareSerial espSerial(11, 10); // RX, TX
#define DHTPIN 2
#define DHTTYPE DHT11 // change to DHT22 if your sensor is DHT22
DHT dht(DHTPIN, DHTTYPE);

const int VIB_PIN = 3;      // digital vibration module DO
const int IR_PIN = 4;       // IR obstacle module OUT
const int CURRENT_PIN = A0; // ACS712 OUT
const int VOLTAGE_PIN = A1; // voltage sensor S/OUT

// MUST be calibrated for your exact modules before trusting measurements.
const float VOLTAGE_RATIO = 5.0;       // typical 0-25V divider module; verify yours
const float ACS_ZERO_V = 2.50;         // calibrate zero-current output
const float ACS_SENSITIVITY = 0.185;   // ACS712 5A; 20A=0.100, 30A=0.066 V/A

float readVoltage() {
  int raw = analogRead(VOLTAGE_PIN);
  float inputAtArduino = raw * (5.0 / 1023.0);
  return inputAtArduino * VOLTAGE_RATIO;
}

float readCurrent() {
  int raw = analogRead(CURRENT_PIN);
  float outputV = raw * (5.0 / 1023.0);
  // Signed current can be useful for generation direction; do not use abs until calibrated.
  float amps = (outputV - ACS_ZERO_V) / ACS_SENSITIVITY;
  return amps;
}

void setup() {
  Serial.begin(9600);
  espSerial.begin(9600);
  pinMode(VIB_PIN, INPUT);
  pinMode(IR_PIN, INPUT);
  dht.begin();
  Serial.println("RailUrja Uno telemetry started");
}

void loop() {
  // Many IR modules are active LOW; invert this if your module is active HIGH.
  bool objectDetected = digitalRead(IR_PIN) == LOW;
  bool vibrationDetected = digitalRead(VIB_PIN) == HIGH;
  float voltage = readVoltage();
  float current = readCurrent();
  float tempC = dht.readTemperature();

  // A digital vibration switch is NOT an accelerometer: 1/0 is only its state.
  // Frequency is deliberately null until measured from a suitable sensor/sampling routine.
  String packet = "{\"deviceId\":\"RailUrja-01\",\"timestamp\":";
  packet += String(millis());
  packet += ",\"ir\":"; packet += (objectDetected ? "1" : "0");
  packet += ",\"trainDetected\":"; packet += (objectDetected ? "true" : "false");
  packet += ",\"vibration\":"; packet += (vibrationDetected ? "1.0" : "0.0");
  packet += ",\"voltage\":"; packet += String(max(0.0f, voltage), 3);
  packet += ",\"current\":"; packet += String(current, 4);
  packet += ",\"frequency\":null,\"temperature\":";
  if (isnan(tempC)) packet += "null"; else packet += String(tempC, 1);
  packet += "}";

  // App firmware bridge sends this JSON line over BLE in safe chunks.
  espSerial.println(packet);
  Serial.println(packet);
  delay(250);
}
