#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// Compatible with the RailUrja app UUIDs.
#define SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define TX_UUID      "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

LiquidCrystal_I2C lcd(0x27, 16, 2);
BLECharacteristic *txCharacteristic = nullptr;
bool connected = false;
String serialLine;
unsigned long lastLcd = 0;
bool lcdPage = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override { connected = true; Serial.println("BLE client connected"); }
  void onDisconnect(BLEServer*) override { connected = false; BLEDevice::startAdvertising(); Serial.println("BLE client disconnected"); }
};

// Send small notification chunks. The app reassembles chunks until newline.
void notifyInChunks(const String &packet) {
  if (!connected || txCharacteristic == nullptr) return;
  const size_t chunkSize = 18; // conservative for default ATT MTU 23
  String framed = packet + "\n";
  for (size_t i = 0; i < framed.length(); i += chunkSize) {
    String part = framed.substring(i, min(i + chunkSize, framed.length()));
    txCharacteristic->setValue(part.c_str());
    txCharacteristic->notify();
    delay(12); // allow BLE stack/browser to receive each notification
  }
}

String jsonValue(const String &line, const String &key) {
  String token = "\"" + key + "\":";
  int p = line.indexOf(token);
  if (p < 0) return "";
  p += token.length();
  int end = line.indexOf(',', p);
  if (end < 0) end = line.indexOf('}', p);
  if (end < 0) return "";
  String v = line.substring(p, end); v.trim(); return v;
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(9600, SERIAL_8N1, 16, 17); // RX2 GPIO16, TX2 GPIO17 from Uno
  Wire.begin(21, 22);
  lcd.init(); lcd.backlight(); lcd.clear(); lcd.print("RailUrja Start");

  BLEDevice::init("ESP32_Railway_Monitor");
  BLEDevice::setMTU(23); // chunking works even at default MTU
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);
  txCharacteristic = service->createCharacteristic(TX_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  txCharacteristic->addDescriptor(new BLE2902());
  txCharacteristic->setValue("{\"status\":\"waiting\"}\n");
  service->start();
  BLEAdvertising *adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID); adv->setScanResponse(true);
  BLEDevice::startAdvertising();
  lcd.clear(); lcd.print("BLE Advertising");
  Serial.println("BLE ready; waiting for Uno JSON lines");
}

void loop() {
  while (Serial2.available()) {
    char c = (char)Serial2.read();
    if (c == '\r') continue;
    if (c == '\n') {
      serialLine.trim();
      if (serialLine.startsWith("{") && serialLine.endsWith("}")) {
        Serial.print("UNO RX: "); Serial.println(serialLine);
        notifyInChunks(serialLine);

        String ir = jsonValue(serialLine, "ir");
        String vib = jsonValue(serialLine, "vibration");
        String volt = jsonValue(serialLine, "voltage");
        String curr = jsonValue(serialLine, "current");
        String temp = jsonValue(serialLine, "temperature");
        if (millis() - lastLcd > 1200) {
          lastLcd = millis(); lcdPage = !lcdPage; lcd.clear();
          if (!lcdPage) {
            lcd.setCursor(0,0); lcd.print(ir == "1" ? "IR:OBJECT FOUND" : "IR:TRACK CLEAR");
            lcd.setCursor(0,1); lcd.print("Vib:"); lcd.print(vib.toFloat(), 2);
          } else {
            lcd.setCursor(0,0); lcd.print("V:"); lcd.print(volt.toFloat(), 2);
            lcd.print(" I:"); lcd.print(curr.toFloat(), 3);
            lcd.setCursor(0,1); lcd.print("Temp:");
            if (temp == "null" || temp.length() == 0) lcd.print("--"); else lcd.print(temp.toFloat(), 1);
            lcd.print(" C");
          }
        }
      } else {
        Serial.print("Bad Uno line: "); Serial.println(serialLine);
      }
      serialLine = "";
    } else if (serialLine.length() < 400) serialLine += c;
    else serialLine = "";
  }
  delay(2);
}
