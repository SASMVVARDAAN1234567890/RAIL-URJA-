RAILURJA - REAL BLE TELEMETRY PATCH

WHAT THIS PATCH DOES
- Keeps the existing full-screen RailUrja app, dashboard, history, alerts, reports, hardware guide and AI assistant UI.
- Fixes BLE receive handling so newline-framed JSON split across multiple BLE notifications is reassembled before parsing.
- Adds Arduino Uno and ESP32 firmware examples using the same BLE UUIDs already configured in the app.
- Does not fabricate live sensor values. Demo Mode is a separate simulation toggle and must remain off for real hardware.

FILES
- src/services/connection.ts: patched BLE notification reassembly and earlier listener registration.
- Arduino_Uno_RailUrja.ino: sensor-reading JSON sender.
- ESP32_RailUrja_BLE_Firmware.ino: BLE server, packet chunking, LCD display.

WIRING
UNO sensors:
- IR OUT -> D4; VCC/GND to appropriate power/ground.
- Digital vibration module DO -> D3.
- DHT11 DATA -> D2 (use DHT22 in code if applicable).
- ACS712 OUT -> A0.
- Voltage module OUT/S -> A1.
- Uno D10 (SoftwareSerial TX) -> ESP32 GPIO16 (RX2) THROUGH A VOLTAGE DIVIDER. Never feed Uno 5V TX directly into ESP32 GPIO.
- Uno D11 (SoftwareSerial RX) <- ESP32 GPIO17 (TX2).
- Uno GND <-> ESP32 GND.
LCD on ESP32: SDA -> GPIO21, SCL -> GPIO22, GND -> GND, VCC according to LCD module requirements. If LCD backpack pulls SDA/SCL up to 5V, use a level shifter or 3.3V-safe pullups for ESP32.

UPLOAD
1. Arduino Uno IDE board = Arduino Uno. Install Adafruit DHT sensor library and Adafruit Unified Sensor if using DHT.
2. Upload Arduino_Uno_RailUrja.ino. Uno Serial Monitor is 9600 baud.
3. ESP32 IDE board = ESP32 Dev Module, upload speed 115200. Upload ESP32_RailUrja_BLE_Firmware.ino. ESP32 Serial Monitor is 115200 baud.
4. Close the Uno Serial Monitor before opening ESP32 Serial Monitor if both are attached to the same IDE window/COM port.
5. Open the app over HTTPS in Chrome/Edge desktop. Keep Demo Mode OFF. Connect to ESP32_Railway_Monitor. BLE service UUID: 6e400001-b5a3-f393-e0a9-e50e24dcca9e. TX Notify UUID: 6e400003-b5a3-f393-e0a9-e50e24dcca9e.
6. ESP32 Serial Monitor should show UNO RX: {...}. App's Serial Telemetry Console should show [BLE RX] {...}.

CALIBRATION / LIMITATIONS
- VOLTAGE_RATIO=5.0 is only an example for a common 0-25V divider module. Confirm your module ratio and never exceed its rating.
- ACS_ZERO_V and ACS_SENSITIVITY depend on the exact ACS712 model and must be calibrated. Signed current may be negative depending on current direction; the app clamps displayed values nonnegative.
- IR modules are commonly active LOW but can differ; invert objectDetected logic if yours is active HIGH.
- A digital vibration switch only provides on/off state. It cannot produce real acceleration in g or frequency. Frequency is null intentionally until an appropriate accelerometer or frequency measurement routine is used.
- The LCD I2C address may be 0x3F instead of 0x27 on some modules.
- This ZIP cannot be deployed to your Render account from here. Upload the patched project to your repository and trigger a Render redeploy. Web Bluetooth requires HTTPS and a compatible browser.
