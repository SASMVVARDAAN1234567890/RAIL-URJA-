import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
  app.use(express.json());
  let latestTelemetry = null;
  const sseClients = [];
  let clientIdCounter = 0;
  app.post("/api/telemetry", (req, res) => {
    const data = req.body;
    if (!data) {
      return res.status(400).json({ error: "Empty payload" });
    }
    const timestamp = data.timestamp ? new Date(data.timestamp).getTime() : Date.now();
    latestTelemetry = {
      ...data,
      serverReceivedAt: Date.now(),
      timestamp: isNaN(timestamp) ? Date.now() : timestamp
    };
    const eventData = `data: ${JSON.stringify(latestTelemetry)}

`;
    for (const client of sseClients) {
      try {
        client.res.write(eventData);
      } catch (err) {
      }
    }
    return res.status(200).json({ success: true, received: latestTelemetry });
  });
  app.get("/api/telemetry/latest", (req, res) => {
    return res.json({ latest: latestTelemetry });
  });
  app.get("/api/telemetry/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();
    const clientId = ++clientIdCounter;
    sseClients.push({ id: clientId, res });
    res.write(`data: ${JSON.stringify({ type: "connected", serverTime: Date.now() })}

`);
    if (latestTelemetry) {
      res.write(`data: ${JSON.stringify(latestTelemetry)}

`);
    }
    req.on("close", () => {
      const idx = sseClients.findIndex((c) => c.id === clientId);
      if (idx !== -1) {
        sseClients.splice(idx, 1);
      }
    });
  });
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      sseClientCount: sseClients.length,
      hasReceivedTelemetry: !!latestTelemetry
    });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RailUrja Server running at http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start RailUrja server:", err);
});
